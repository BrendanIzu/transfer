import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('UserDatabase', 'root', '!Zu8905933', {
    dialect: 'mysql',
    host: 'localhost', 
});

export default sequelize;