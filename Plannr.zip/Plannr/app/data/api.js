export const API_URL = 'http://10.37.157.189:5000';

export const authAPI = async (email, isLogin, name, password) => {
    const payload = {
        email,
        name,
        password,
    };
        
    return fetch(`${API_URL}/${isLogin ? 'login' : 'signup'}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    });
};

export const backgroundColorAPI = (groupId, personId) => {
    const payload = {
        groupId,
        personId,
    }
    
    return fetch(`${API_URL}/colors/color`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    });
};

export const createEventAPI = (date, description, groupId, location, personId, title) => {
    const payload = {
        date, 
        description,
        groupId,
        location, 
        personId,
        title,
    }
    fetch(`${API_URL}/events/create`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    })
};

export const eventsAPI = personId => {
    const payload = {
        personId
    }
    
    return fetch(`${API_URL}/events/upcoming`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    })
};

export const groupsAPI = personId => {
    const payload = {
        personId,
    }
    return fetch(`${API_URL}/groups`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    })
};

export const loginAPI = async token => {
    return fetch(`${API_URL}/private`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`, 
        },
    });
};

export const membersAPI = (groupId) => {
    const payload = {
        groupId,
    };
    
    return fetch(`${API_URL}/groups/members`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    })
};

export const personIdAPI = email => {
    return fetch(`${API_URL}/user/userId`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({email}),
    });
};