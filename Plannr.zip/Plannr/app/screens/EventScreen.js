import React from 'react';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Moment from 'moment';

import AppButton from '../components/AppButton';
import AppText from '../components/AppText';
import AppBackButton from '../components/AppBackButton';
import AppTextButton from '../components/AppTextButton';
import { ScrollView } from 'react-native-gesture-handler';

const formatDate = (date) => {
    Moment.locale('en');
    return Moment(date).format('LLLL');
};

function EventScreen({route}) {
    const navigation = useNavigation();
    const doSomething = () => {
        navigation.navigate('HomeScreen')
    }
    
    return (
        <View style={styles.background}>
            <SafeAreaView style={styles.container}>
                <View style={styles.header}>
                    <AppBackButton back='HomeScreen' textStyle={{fontSize: 18}} type='text' />
                    {/* <AppText>{'event details'}</AppText> */}
                    <AppTextButton label='Edit' textStyle={{fontSize: 18}}/>
                </View>
                <ScrollView>
                    <View style={styles.body}>
                        <View style={styles.title}>
                            <AppText style={{fontWeight: 'bold', fontSize: 30}}>{route.params.event.title}</AppText>
                        </View>
                        <View style={styles.title}>
                            <AppText style={{color: 'grey', fontSize: 20}}>{route.params.event.group_id}</AppText>
                        </View>
                    </View>
                    
                    <View style={styles.date}>
                        <AppText style={{color: 'grey', fontSize: 18}}>{formatDate(route.params.event.date)}</AppText>
                    </View>
                    
                    <View style={styles.description}>
                        <AppText style={{fontSize: 18}}>{route.params.event.description}</AppText>
                    </View>
                </ScrollView>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    container: {
        flex: 1,
        margin: 18,
    },
    date: {
        marginTop: 10,
    },
    description: {
        marginTop: 10,
        minHeight: 80,
        backgroundColor: 'white'
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
        marginBottom: 30,
    },
    title: {
        marginTop: 5,
        maxWidth: 200,
    },
})

export default EventScreen;