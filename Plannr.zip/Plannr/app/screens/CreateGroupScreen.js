import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import DropDownPicker from 'react-native-dropdown-picker';

import AppButton from '../components/AppButton';
import AppBackButton from '../components/AppBackButton';
import AppInformationInput from '../components/AppInformationInput';
import AppAddMembers from '../components/AppAddMembers';
import AppShowMembers from '../components/AppShowMembers';
import AppColorPicker from '../components/AppColorPicker';
import AppGroupPicker from '../components/AppGroupPicker';
import { ScrollView } from 'react-native-gesture-handler';

const API_URL = Platform.OS === 'ios' ? 'http://192.168.0.225:5000' : 'http://10.0.2.2:5000';

function CreateGroupScreen(props) {
    const text = React.useState("starting text");
    const [results, setResults] = useState([]);
    const [groupName, setGroupName] = useState('');
    const [personsAdded, setPersonsAdded] = useState([PERSON_ID]);
    const [color, setColor] = useState('');
    
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(null);
    const [items, setItems] = useState([
      {label: 'red', value: 'red'},
      {label: 'blue', value: 'blue'}
    ]);
    
    const onAddPersonHandler = (item) => {
        console.log(item);
        if(personsAdded.includes(item)) {
            setPersonsAdded(personsAdded.filter(person => person !== item));
        } else {
            setPersonsAdded(prevArray => [...prevArray, item]);
            console.log(personsAdded);
        }
    };
    
    const onGroupCreated = () => {
        props.navigation.navigate('HomeScreen');
    };
    
    const onChangeTextHandler = (text) => {
        const payload = {
            name: text,
            owner: PERSON_ID,
        };
        
        fetch(`${API_URL}/user/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        })
        .then((response) => response.json())
        .then((json) => {          
            const res_array = []; 
            for(let i in json) { 
                res_array.push(json[i]); 
            }; 
            setResults(res_array);
        })
        .catch((error) => {
            console.error(error);
        })
    }
    
    const onSubmitHandler = () => {
        for (let i=0; i<personsAdded.length; i++) {
            let payload = null;
            if (i == 0) {
                payload = {
                    owner: PERSON_ID,
                    groupId: PERSON_ID+groupName,
                    groupName,
                    personId: personsAdded[i],
                    color,
                }; 
            } else {
                payload = {
                    owner: PERSON_ID,
                    groupId: personsAdded[i]+groupName,
                    groupName,
                    personId: personsAdded[i].id,
                    color,
                };
            }

            fetch(`${API_URL}/groups/create`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            })
            .then(async res => { 
                try {
                    const jsonRes = await res.json();
                    
                    if (res.status !== 200) {
                        console.log('failed to create group');
                    } else {
                        onGroupCreated();
                    }
                } catch (err) {
                    console.log(err);
                };
            })
            .catch(err => {
                console.log(err);
            });
        }
    };
    
    return (
        <SafeAreaView style={styles.background}>   
            <View style={styles.row}>
                <AppButton label='done' onPress={onSubmitHandler}/>
                <AppBackButton back='HomeScreen'/>  
            </View>

            <AppInformationInput 
                onChangeText={(text) => setGroupName(text)}
                placeholder='Group name'/>

            <AppAddMembers
                placeholder='Add members'
                onChangeText={(text) => onChangeTextHandler(text)}
                onPress={(item) => {onAddPersonHandler(item); console.log('we also need to mark the person as checked in search menu')}}
                data={results}/>
            <AppShowMembers/>
            <AppColorPicker onChangeValue={(value) => {setColor(value); console.log(value)}}/>

    </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        paddingTop: 70,
    },
    input: {
        backgroundColor: 'white',
    },
    row: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-evenly'
    },
    test: {
        backgroundColor: 'orange',
        width: 100,
        margin: 10,
    }
})

export default CreateGroupScreen;