import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import AppButton from '../components/AppButton';
import AppBackButton from '../components/AppBackButton';
import AppDatePicker from '../components/AppDatePicker';
import AppGroupPicker from '../components/AppGroupPicker';
import AppInformationInput from '../components/AppInformationInput';
import AppText from '../components/AppText';

import { createEventAPI, membersAPI } from '../data/api';
import { ScrollView } from 'react-native-gesture-handler';

function CreateEventScreen(props) {   
    const [date, setDate] = useState(new Date());
    const [description, setDescription] = useState('');
    const [groupId, setGroupId] = useState('');
    const [isError, setIsError] = useState(false);
    const [location, setLocation] = useState('');
    const [message, setMessage] = useState('');
    const [title, setTitle] = useState('');
    
    const onSubmitHandler = () => {  
        if(groupId == '') {
            setMessage('Must select group');
            setIsError(true);
            return;
        }

        membersAPI(groupId)
        .then((response) => response.json())
        .then((json) => {
            const res_array = [];
            for(let i in json) {
                res_array.push(json[i].person_id);
            }
            return res_array;
        })
        .then((res_array) => {
            for(let i=0; i<res_array.length; i++) {
                createEventAPI(date, description, groupId, location, res_array[i], title)
                .then(async res => { 
                    try {
                        const jsonRes = await res.json();
                        
                        if (res.status !== 200) {
                            console.log('failed to create event');
                        }
                    } catch (err) {
                        console.log(err);
                    };
                })
                .catch(err => {
                    console.log(err);
                });
            }
        })
        .catch((error) => {
            console.error(error);
        })
        props.navigation.navigate('HomeScreen');
    };
    
    const getMessage = () => {
        const status = isError ? `Error: ` : `Success: `;
        return status + message;
    }
    
    return (
        <SafeAreaView style={styles.background}>   
            <View style={styles.row}>
                <AppButton label='done' onPress={onSubmitHandler}/>
                <AppBackButton back='HomeScreen'/>  
            </View>
            
            <AppInformationInput 
                onChangeText={(text) => setTitle(text)}
                placeholder='Add title'/>
                
            <AppInformationInput 
                onChangeText={(text) => setDescription(text)}
                placeholder='Add description'/>
                
            <AppInformationInput 
                onChangeText={(text) => setLocation(text)}
                placeholder='Add location'/>
            
            <View style={styles.row}>
                <AppGroupPicker onChangeValue={(groupId) => setGroupId(groupId)} onPress={() => setIsError(false)}/>
                <AppDatePicker 
                    date={date}
                    onChange={(event, date) => setDate(date)}/>
            </View>
            
            { isError && <View style={{marginLeft: 20, marginTop: -10}}>
                <AppText style={[styles.message, {color: isError ? 'red' : 'green'}]}>{message ? getMessage() : null}</AppText>  
            </View> }

        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        paddingTop: 70,
    },
    input: {
        backgroundColor: 'white',
    },
    message: {
        fontSize: 16,
        marginVertical: '5%',
    },
    row: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-evenly'
    },
    test: {
        backgroundColor: 'orange',
        width: 100,
        margin: 10,
    }
})

export default CreateEventScreen;