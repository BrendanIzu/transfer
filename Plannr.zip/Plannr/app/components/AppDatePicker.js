import React from 'react';
import { StyleSheet, View } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';

function AppDatePicker({date, onChange}) {
    return (
        <View style={styles.container}>
            <DateTimePicker 
                style={styles.picker}
                mode="datetime" 
                value={date} 
                onChange={onChange}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        height: 50,
        width: 200,
        margin: 10,
    },
    picker: {
        flex: 1,
        justifyContent: 'center'
    }
})

export default AppDatePicker;