import React, { useState} from 'react';
import { FlatList, TextInput, View, StyleSheet } from 'react-native';

import AppText from './AppText';
import PersonItem from './PersonItem';

const API_URL = Platform.OS === 'ios' ? 'http://localhost:5000' : 'http://10.0.2.2:5000';

function AppAddMembers({ onChangeText, onPress, placeholder, data }) { 
    const [personsAdded, setPersonsAdded] = useState([]);
    
    const onAddPersonHandler = (item) => {
        onPress(item);
        if(personsAdded.includes(item)) {
            setPersonsAdded(personsAdded.filter(person => person !== item));
        } else {
            setPersonsAdded(prevArray => [...prevArray, item]);
            console.log(personsAdded);
        }
    };
    
    return (
        <View style={styles.container}>
            <FlatList
                numColumns={3}
                data={personsAdded}
                renderItem={ 
                    ({ item }) => {return <PersonItem person={item}/>} }
                ListEmptyComponent={<AppText></AppText>}
                keyExtractor={item => item.id}
                scrollEnabled={false}/>
            <TextInput
                multiline={true}
                placeholder={placeholder}
                autoCorrect={false}
                onChangeText={onChangeText}
                style={styles.input}
                autoCapitalize={'none'}/>
            <FlatList
                data={data}
                renderItem={ 
                    ({ item }) => {return <PersonItem onPress={() => onAddPersonHandler(item)} person={item}/>} }
                ListEmptyComponent={<AppText></AppText>}
                keyExtractor={item => item.id}
                scrollEnabled={false}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        height: 'auto',
        width: '100%',
        margin: 10,
        justifyContent: 'flex-start',
    },
    input: {
        color: 'black',
        maxHeight: 100,
        paddingLeft: 30,
        paddingRight: 20,
        paddingBottom: 10,
    },
})

export default AppAddMembers;