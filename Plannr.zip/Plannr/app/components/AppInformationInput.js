import React from 'react';
import { TextInput, View, StyleSheet } from 'react-native';

function AppInformationInput({ onChangeText, placeholder, label, }) {
    return (
        <View style={styles.container}>
            <TextInput
                multiline={true}
                placeholder={placeholder}
                secureTextEntry={label === 'password'}
                autoCorrect={false}
                onChangeText={onChangeText}
                style={styles.input}
                autoCapitalize={'none'}/></View>
    );
}

const styles = StyleSheet.create({
    container: {
        height: 'auto',
        width: '100%',
        margin: 10,
        justifyContent: 'flex-start',
        borderBottomWidth: 0.3,
        borderBottomColor: 'grey',
    },
    input: {
        color: 'black',
        maxHeight: 100,
        paddingLeft: 30,
        paddingRight: 20,
        paddingBottom: 10,
    },
})

export default AppInformationInput;