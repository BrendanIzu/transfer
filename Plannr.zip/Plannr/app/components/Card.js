import { sub } from 'date-fns';
import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';

import AppText from './AppText';

function Card({card}) {
    return (
        <View style={styles.card}>
            <View style={styles.header}>
                <Text style={styles.titleText}>{card.name}</Text>
            </View>
            <View style={styles.body}>
                <Text>LOCATION: {card.location}</Text>
                <Text>DESCRIPTION: {card.description}</Text>
                <Text>PEOPLE: </Text>
            </View>
            <View style={styles.footer}>
                <Text>ACTION NEEDED</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    body: {
        width: '100%',
        backgroundColor: 'lightgrey',
        borderRadius: 5,
        padding: 10,
        margin: 10,
    },
    card: {
        backgroundColor: 'beige',
        padding: 30,
        height: '80%',
        width: '100%',
        alignItems: 'center',
    },
    footer: {
        width: '100%',
        backgroundColor: 'lightgrey',
        borderRadius: 5,
        padding: 10,
        margin: 10,
        
        alignItems: 'center',
    },
    header: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    titleText: {
        fontSize: 35,
        fonst: 'strong',
    }
})

export default Card;