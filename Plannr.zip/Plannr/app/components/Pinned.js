import React from 'react';
import { FlatList, StyleSheet, View, } from 'react-native';

import AppText from '../components/AppText';
import GroupIcon from './GroupIcon';

const events = [1,2,3];

function Pinned(props) {
    return (
        <View>
            <FlatList
                data={events}
                renderItem={() => { return <GroupIcon/>}}
                ListEmptyComponent={<AppText>NO EVENTS CLICK TO PLAN EVENT</AppText>}
                keyExtractor={item => item.group_id}
                numColumns={3}
                columnWrapperStyle={styles.row}
                scrollEnabled={false}/>    
        </View>
    );
}

const styles = StyleSheet.create({
    row: {
        flex: 1,
        justifyContent: 'space-around',
    }
})

export default Pinned;