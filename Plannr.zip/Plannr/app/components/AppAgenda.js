import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, FlatList } from 'react-native';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';

import AppText from './AppText';
import Modal from 'react-native-modal';
import Card from './Card';
import GroupIcon from './GroupIcon';

import groups from '../data/Groups'

const API_URL = Platform.OS === 'ios' ? 'http://localhost:5000' : 'http://10.0.2.2:5000';

function AppAgenda({date}) {
    const [events, setEvents] = useState([]);
    
    const getMonth = (date) => {
        switch(date) {
            case 1: return "January"
            case 2: return "February"
            case 3: return "March"
            case 4: return "April"
            case 5: return "May"
            case 6: return "June"
            case 7: return "July"
            case 8: return "August"
            case 9: return "September"
            case 10: return "October"
            case 11: return "November"
            case 12: return "December"
        }
    }
    
    const getEvents = () => {
        const dayString = '_'+date.month+'_'+date.day+'_'+date.year;
        console.log(dayString)
        return events[dayString];
    }
    
    const getEventsFromApi = () => {
        const payload = {
            date,
        }
        fetch(`${API_URL}/events/day`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        })
        .then((response) => response.json())
        .then((json) => {          
            const res_array = []; 
            for(let i in json) { 
                res_array.push(json[i]); 
            }; 
            setEvents(res_array);
            console.log(json);
        })
        .catch((error) => {
            console.error(error);
        })
    }
    
    const getStyle = (group) => {
        var groupID = group;
        
        if (!group) {
            groupID = '_0';
        } else {
            groupID = '_'+group;
        }
        
        return {
            backgroundColor: groups[groupID].groupColor,
            padding: 20,
            marginVertical: 8,
            marginHorizontal: 16,
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            borderRadius: 5,
        }
    }
    
    const month = getMonth(date.month);
    const day = date.day;
    const year = date.year;
    
    const displayEvents = events[0];
    
    const [showCard, setShowCard] = useState(false)
    const [card, setCard] = useState([]);
    
    const Item = ({ item }) => (
        <Pressable style={getStyle(item.group)}
            onPress={() => {console.log(item.group)
                            setShowCard(true) 
                            setCard(item)}}>
          <Text style={styles.title}>{item.name}</Text>
          {item.alerts && <GroupIcon/>}                 
        </Pressable>
    );
    
    const renderItem = ({ item }) => (
        <Item item={item} />
    );
    
    useEffect(() => {
        getEventsFromApi();
    }, [])
    
    return (
        <View style={styles.container}>
            { !showCard && <View style={styles.listContainer}>
                <AppText>{month+" "+day+", "+year}</AppText>
                <FlatList style={styles.agenda}
                    data={events}
                    renderItem={renderItem}
                    ListEmptyComponent={<Text>NO EVENTS CLICK TO PLAN EVENT</Text>}
                    keyExtractor={item => item.name}/>
            </View> }
            <Modal style={styles.cardContainer} visible={showCard}>
                <Pressable style={styles.closeButton}
                    onPress={() => {setShowCard(false)}}>
                    <AppText>close modal</AppText>
                </Pressable>
                <Card card={card}/>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    agenda: {
        width: '100%',
        height: '95%',
    },
    button: {
        height: 50,
        width: 200,
        color: 'yellow',
        backgroundColor: 'green',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    cardContainer: {
        height: 600,
        width: '100%',
        margin: 0,
        backgroundColor: 'blue',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    closeButton: {
        width: 100,
        height: 30,
        backgroundColor: 'dodgerblue',
        borderRadius: 10,
        dipslay: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    container: {
        height: '95%',
        widht: '100%',
        backgroundColor: 'white',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        borderRadius: 10,
    },
    item: {
        backgroundColor: '#f9c2ff',
        padding: 20,
        marginVertical: 8,
        marginHorizontal: 16,
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    listContainer: {
        width: '100%',
        height: '95%',
    }
})

export default AppAgenda;