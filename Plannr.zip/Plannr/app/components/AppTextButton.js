import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';

import AppText from './AppText';

function AppTextButton({ buttonStyle, label, onPress, style, textStyle }) {
    return (
        <TouchableOpacity style={[styles.button, buttonStyle, style]} onPress={onPress}>
            <AppText style={[styles.text, textStyle]}>{label}</AppText>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    text: {
        color: 'black',
        fontWeight: 'bold',
    }
})

export default AppTextButton;