import React from 'react';
import { StyleSheet,  View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';

import AppText from './AppText';

function PersonItem({person, onPress}) {
    return (
        <TouchableOpacity style={styles.container} onPress={onPress}>
            <AppText>
                {person.name}
            </AppText>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'lightgrey',
        width: 150,
        height: 50,
        padding: 10,
        margin: 10,
        justifyContent: 'center',
 
    }
})

export default PersonItem;