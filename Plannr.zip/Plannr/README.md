# Plannr

# Getting Started
1. Download src code 
2. Run `npm install` to install necessary packages
3. Run `npm start` to launch app
